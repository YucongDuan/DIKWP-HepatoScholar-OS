import csv
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List, Tuple

from .models import LiteratureRecord, DIKWPLedgerEntry, ClaimCard, ClosureResult, AnalysisReport, to_dict
from .text_utils import normalize_text, split_sentences, contains_any

DISEASE_TERMS = {
    "MASLD/MASH": ["masld", "mash", "nafld", "nash", "steatotic", "steatohepatitis", "fatty liver"],
    "HBV": ["hbv", "hepatitis b", "chronic hepatitis b"],
    "HCV": ["hcv", "hepatitis c"],
    "HCC": ["hepatocellular carcinoma", "hcc", "liver cancer"],
    "Cirrhosis": ["cirrhosis", "portal hypertension", "varices", "decompensation", "ascites"],
    "DILI": ["drug-induced liver injury", "dili", "hepatotoxicity"],
    "Cholestatic": ["pbc", "psc", "cholestatic", "biliary"],
    "Autoimmune": ["autoimmune hepatitis", "aih"],
    "Transplantation": ["transplant", "graft", "machine perfusion"],
    "Fibrosis": ["fibrosis", "fibroscan", "elastography", "collagen"],
}

DESIGN_WEIGHTS = {
    "systematic_review": 0.88,
    "meta_analysis": 0.9,
    "randomized_trial": 0.86,
    "clinical_trial": 0.8,
    "cohort": 0.68,
    "case_control": 0.58,
    "cross_sectional": 0.5,
    "guideline": 0.82,
    "mechanistic": 0.46,
    "review": 0.42,
    "case_series": 0.32,
    "case_report": 0.22,
    "preprint": 0.25,
    "unknown": 0.2,
}

IMPRECISE_TERMS = ["may", "might", "could", "suggest", "trend", "associated", "possible", "potential", "preliminary", "exploratory"]
STRONG_CLAIM_TERMS = ["prove", "guarantee", "cure", "always", "never", "definitive", "breakthrough"]


def load_records(path: str) -> List[LiteratureRecord]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    records = data.get("records", data if isinstance(data, list) else [])
    out = []
    for i, item in enumerate(records, 1):
        item = dict(item)
        item.setdefault("record_id", f"R{i:03d}")
        out.append(LiteratureRecord(**{k: v for k, v in item.items() if k in LiteratureRecord.__dataclass_fields__}))
    return out


def detect_topics(record: LiteratureRecord) -> List[str]:
    text = " ".join([record.title, record.abstract, record.conclusion, " ".join(record.keywords), " ".join(record.disease_area)])
    topics = []
    for area, terms in DISEASE_TERMS.items():
        if contains_any(text, terms):
            topics.append(area)
    return topics or ["Unclassified"]


def normalize_design(design: str) -> str:
    d = (design or "unknown").lower().replace("-", "_").replace(" ", "_")
    if "meta" in d:
        return "meta_analysis"
    if "systematic" in d:
        return "systematic_review"
    if "random" in d or "rct" in d:
        return "randomized_trial"
    if "trial" in d:
        return "clinical_trial"
    if "cohort" in d:
        return "cohort"
    if "case_control" in d or "case-control" in d:
        return "case_control"
    if "cross" in d:
        return "cross_sectional"
    if "guideline" in d or "guidance" in d:
        return "guideline"
    if "mechan" in d or "basic" in d:
        return "mechanistic"
    if "case_series" in d:
        return "case_series"
    if "case_report" in d:
        return "case_report"
    if "preprint" in d:
        return "preprint"
    if "review" in d:
        return "review"
    return "unknown"


def evidence_score(record: LiteratureRecord) -> float:
    d = normalize_design(record.study_design)
    score = DESIGN_WEIGHTS.get(d, 0.2)
    if record.sample_size:
        score += min(0.08, math.log10(max(record.sample_size, 1))/50)
    if record.doi or record.pmid:
        score += 0.04
    if record.year and record.year >= 2020:
        score += 0.03
    if record.synthetic:
        score -= 0.06
    if any(t in (record.conclusion + " " + record.abstract).lower() for t in STRONG_CLAIM_TERMS):
        score -= 0.08
    return round(max(0.0, min(1.0, score)), 4)


def decision_from_score(score: float) -> str:
    if score >= 0.78:
        return "evidence_anchor"
    if score >= 0.58:
        return "reviewable_support"
    if score >= 0.38:
        return "hypothesis_only"
    return "weak_or_context_only"


def extract_claims(record: LiteratureRecord) -> List[str]:
    text = record.conclusion or record.abstract
    sentences = split_sentences(text)
    if not sentences and record.title:
        return [record.title]
    candidates = []
    for s in sentences:
        low = s.lower()
        if any(k in low for k in ["reduce", "increase", "associated", "improve", "predict", "risk", "response", "survival", "fibrosis", "diagnostic", "safety", "effective"]):
            candidates.append(s)
    return candidates[:4] or sentences[:2]


def build_ledger(record: LiteratureRecord) -> DIKWPLedgerEntry:
    topics = detect_topics(record)
    score = evidence_score(record)
    design = normalize_design(record.study_design)
    missing = []
    for field in ["doi", "pmid", "abstract", "outcome", "population", "intervention_or_exposure"]:
        if not getattr(record, field):
            missing.append(field)
    D = {
        "title": record.title,
        "year": record.year,
        "journal": record.journal,
        "doi": record.doi,
        "pmid": record.pmid,
        "synthetic_sample_record": record.synthetic,
    }
    I = {
        "disease_topics": topics,
        "population": record.population,
        "intervention_or_exposure": record.intervention_or_exposure,
        "comparator": record.comparator,
        "outcome": record.outcome,
        "keywords": record.keywords,
    }
    K = {
        "study_design": design,
        "sample_size": record.sample_size,
        "candidate_claims": extract_claims(record),
        "mechanism_terms": extract_mechanism_terms(record),
    }
    W = {
        "evidence_score": score,
        "decision": decision_from_score(score),
        "clinical_translation_caution": "Do not use as diagnosis or treatment guidance; route to expert review.",
        "bias_flags": bias_flags(record),
    }
    P = {
        "research_purpose": "Aggregate, organize, and mine liver disease academic evidence for research planning.",
        "recommended_next_step": next_step(record, score),
    }
    R = {
        "missing_fields": missing,
        "reliability": reliability_label(score),
        "residual": residual_statement(record, missing),
        "kill_conditions": ["source cannot be verified", "study design misclassified", "endpoint denominator missing", "claim not supported by text"],
    }
    return DIKWPLedgerEntry(record.record_id, D, I, K, W, P, R)


def extract_mechanism_terms(record: LiteratureRecord) -> List[str]:
    text = (record.title + " " + record.abstract + " " + record.conclusion).lower()
    terms = []
    vocab = ["fibrosis", "inflammation", "insulin resistance", "bile acid", "microbiome", "immune", "viral replication", "portal pressure", "carcinogenesis", "steatosis", "oxidative stress", "metabolism"]
    for v in vocab:
        if v in text:
            terms.append(v)
    return terms


def bias_flags(record: LiteratureRecord) -> List[str]:
    flags = []
    text = (record.abstract + " " + record.conclusion).lower()
    if record.sample_size is None:
        flags.append("sample_size_missing")
    elif record.sample_size < 100 and normalize_design(record.study_design) not in ["mechanistic", "case_report", "case_series"]:
        flags.append("small_sample")
    if any(t in text for t in IMPRECISE_TERMS):
        flags.append("imprecise_language")
    if any(t in text for t in STRONG_CLAIM_TERMS):
        flags.append("overclaim_language")
    if not (record.doi or record.pmid):
        flags.append("identifier_missing")
    return flags


def reliability_label(score: float) -> str:
    if score >= 0.78: return "Supported"
    if score >= 0.58: return "Provisional-Supported"
    if score >= 0.38: return "Provisional"
    return "Weak"


def next_step(record: LiteratureRecord, score: float) -> str:
    design = normalize_design(record.study_design)
    if score >= 0.78:
        return "Use as evidence anchor after full-text verification and extraction."
    if design in ["mechanistic", "case_series", "case_report"]:
        return "Use for hypothesis generation, mechanism map, or case context only."
    return "Route to human full-text review and confirm denominator, endpoint, and risk of bias."


def residual_statement(record: LiteratureRecord, missing: List[str]) -> str:
    if missing:
        return "Missing or under-specified fields: " + ", ".join(missing)
    if record.synthetic:
        return "Synthetic demo record; replace with real PubMed/PMC/ClinicalTrials source before use."
    return "No major metadata residual detected, but full-text extraction remains required."


def semantic_closure(record: LiteratureRecord) -> ClosureResult:
    anchors = []
    noise = []
    residuals = []
    topics = detect_topics(record)
    if topics != ["Unclassified"]:
        anchors.append("disease_topic:" + "/".join(topics))
    if record.study_design:
        anchors.append("study_design:" + normalize_design(record.study_design))
    if record.sample_size:
        anchors.append(f"sample_size:{record.sample_size}")
    else:
        residuals.append("sample_size_missing")
    if record.outcome:
        anchors.append("outcome:" + record.outcome)
    else:
        residuals.append("outcome_missing")
    text = (record.abstract + " " + record.conclusion).lower()
    if any(t in text for t in IMPRECISE_TERMS):
        noise.append("imprecise_association_language")
    if any(t in text for t in STRONG_CLAIM_TERMS):
        noise.append("overclaim_language")
    if len(anchors) >= 4 and not residuals:
        level, base = "S4 Stable Closure", 0.9
    elif len(anchors) >= 3:
        level, base = "S3 Supported Closure", 0.74
    elif len(anchors) >= 2:
        level, base = "S2 Provisional Closure", 0.55
    else:
        level, base = "S1 Fragile Closure", 0.34
    base -= min(0.2, 0.05 * len(noise))
    base -= min(0.25, 0.06 * len(residuals))
    return ClosureResult(record.record_id, anchors, noise, residuals, level, round(max(0.0, base), 3), "Closure depends on explicit anchors and whether local noise changes the research purpose.")


def make_claim_cards(record: LiteratureRecord) -> List[ClaimCard]:
    score = evidence_score(record)
    dec = decision_from_score(score)
    topics = detect_topics(record)
    cards = []
    for i, claim in enumerate(extract_claims(record), 1):
        disease = topics[0] if topics else "Unclassified"
        cards.append(ClaimCard(
            claim_id=f"{record.record_id}-C{i}",
            record_id=record.record_id,
            claim_text=claim,
            disease_area=disease,
            evidence_type=normalize_design(record.study_design),
            evidence_score=score,
            decision=dec,
            support_scope="Supported only within the stated population, intervention/exposure, comparator and endpoint.",
            residual=residual_statement(record, [] if record.abstract else ["abstract"]),
            kill_condition="Full text contradicts abstract, endpoint denominator changes, or study design/sample size is misreported."
        ))
    return cards


def gap_mining(records: List[LiteratureRecord]) -> List[str]:
    topics = Counter()
    designs = defaultdict(Counter)
    populations = Counter()
    endpoints = Counter()
    for r in records:
        for t in detect_topics(r):
            topics[t] += 1
            designs[t][normalize_design(r.study_design)] += 1
        if r.population:
            populations[r.population.lower()] += 1
        if r.outcome:
            endpoints[r.outcome.lower()] += 1
    gaps = []
    for area in ["Autoimmune", "Cholestatic", "DILI", "Transplantation"]:
        if topics[area] == 0:
            gaps.append(f"Topic gap: {area} records absent in current corpus; add targeted searches.")
    for area, cnt in topics.items():
        if cnt >= 2 and designs[area]["randomized_trial"] == 0 and area not in ["HCC", "Cirrhosis"]:
            gaps.append(f"Evidence gap: {area} has records but no randomized trial in this corpus.")
    if not any("pediatric" in p or "child" in p for p in populations):
        gaps.append("Population gap: pediatric or adolescent liver disease evidence not represented.")
    if not any("quality of life" in e for e in endpoints):
        gaps.append("Endpoint gap: patient-reported quality-of-life endpoints not represented.")
    if not any("cost" in e or "cost-effectiveness" in e for e in endpoints):
        gaps.append("Translation gap: cost-effectiveness / implementation endpoints are missing.")
    return gaps[:10]


def write_json(path: Path, data: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def analyze(input_path: str, out_dir: str) -> Dict[str, Any]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    records = load_records(input_path)
    ledgers = [build_ledger(r) for r in records]
    closures = [semantic_closure(r) for r in records]
    cards = [c for r in records for c in make_claim_cards(r)]
    topics = Counter(t for r in records for t in detect_topics(r))
    decisions = Counter(c.decision for c in cards)
    mean_score = round(sum(evidence_score(r) for r in records)/len(records), 4) if records else 0.0
    gaps = gap_mining(records)
    report = AnalysisReport(
        system="DIKWP HepatoScholar OS",
        version="0.1.0",
        record_count=len(records),
        decision_summary=dict(decisions),
        topic_counts=dict(topics),
        mean_evidence_score=mean_score,
        top_research_gaps=gaps,
        medical_boundary="Research organization only; not for diagnosis, treatment, prescribing, triage, or clinical decisions."
    )
    write_json(out/"hepatoscholar_report.json", to_dict(report))
    write_json(out/"dikwp_literature_ledger.json", [to_dict(x) for x in ledgers])
    write_json(out/"semantic_closure_report.json", [to_dict(x) for x in closures])
    write_json(out/"knowledge_triples.json", extract_triples(records))
    # CSVs
    with (out/"evidence_matrix.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["record_id","title","topics","study_design","sample_size","evidence_score","decision","missing_fields","bias_flags"])
        for r,l in zip(records, ledgers):
            w.writerow([r.record_id, r.title, ";".join(l.I["disease_topics"]), l.K["study_design"], r.sample_size or "", l.W["evidence_score"], l.W["decision"], ";".join(l.R["missing_fields"]), ";".join(l.W["bias_flags"])])
    with (out/"claim_cards.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(to_dict(cards[0]).keys()) if cards else ["claim_id"])
        w.writeheader()
        for c in cards:
            w.writerow(to_dict(c))
    (out/"research_gap_report.md").write_text(render_gap_report(gaps, topics, records), encoding="utf-8")
    (out/"query_strategy_pack.md").write_text(render_query_strategy(), encoding="utf-8")
    (out/"recommendations.md").write_text(render_recommendations(report, gaps), encoding="utf-8")
    return to_dict(report)


def extract_triples(records: List[LiteratureRecord]) -> List[Dict[str, str]]:
    triples=[]
    for r in records:
        topics = detect_topics(r)
        subj = topics[0] if topics else "Liver disease"
        if r.intervention_or_exposure:
            triples.append({"subject": r.intervention_or_exposure, "predicate":"studied_in", "object": subj, "record_id": r.record_id})
        if r.outcome:
            triples.append({"subject": subj, "predicate":"has_endpoint", "object": r.outcome, "record_id": r.record_id})
        for m in extract_mechanism_terms(r):
            triples.append({"subject": subj, "predicate":"mechanism_term", "object": m, "record_id": r.record_id})
    return triples


def render_gap_report(gaps, topics, records):
    lines = ["# DIKWP HepatoScholar Research Gap Report", "", "## Topic distribution", ""]
    for k,v in topics.items(): lines.append(f"- {k}: {v}")
    lines += ["", "## Top gaps", ""]
    for g in gaps: lines.append(f"- {g}")
    lines += ["", "## DIKWP 4.0 interpretation", "", "Research gaps are not only missing data. They may be missing denominators, endpoints, populations, mechanisms, full-text links, or P-layer research purpose. Use this report to plan targeted searches, full-text extraction, and expert review."]
    return "\n".join(lines)


def render_query_strategy():
    return """# Liver Disease Query Strategy Pack\n\n## Core search blocks\n\n### MASLD / MASH\n`(MASLD OR MASH OR NAFLD OR NASH OR steatotic liver disease OR steatohepatitis) AND (fibrosis OR biomarker OR therapy OR outcome)`\n\n### Viral hepatitis\n`(hepatitis B OR HBV OR hepatitis C OR HCV) AND (antiviral OR cure OR fibrosis OR cirrhosis OR hepatocellular carcinoma)`\n\n### HCC\n`(hepatocellular carcinoma OR HCC OR liver cancer) AND (immunotherapy OR surveillance OR biomarker OR survival)`\n\n### Cirrhosis / portal hypertension\n`(cirrhosis OR portal hypertension OR varices OR ascites) AND (noninvasive OR beta blocker OR TIPS OR outcome)`\n\n## Recommended sources\n\n- PubMed / MEDLINE for biomedical citations.\n- Europe PMC for publications, preprints and open full-text links.\n- ClinicalTrials.gov for trial status and study records.\n- Guideline sources such as AASLD/EASL for practice guidance, with clear separation from research hypotheses.\n\n## Workflow\n\n1. Draft PICO/PECO question.\n2. Build search terms with MeSH plus free-text synonyms.\n3. Export metadata to JSON/CSV/BibTeX.\n4. Ingest into HepatoScholar.\n5. Review DIKWP evidence ledger and semantic closure report.\n6. Route evidence anchors to full-text extraction and expert review.\n"""


def render_recommendations(report, gaps):
    d = report.decision_summary
    return f"""# DIKWP HepatoScholar Recommendations\n\n## Current decision summary\n\n{json.dumps(d, indent=2, ensure_ascii=False)}\n\n## Immediate actions\n\n1. Replace all synthetic records with exported PubMed/PMC/ClinicalTrials metadata before formal use.\n2. Route `evidence_anchor` records to full-text extraction.\n3. Route `hypothesis_only` records to mechanism-map or gap-mining use only.\n4. Add missing pediatric, cost-effectiveness, quality-of-life, and implementation endpoints if relevant.\n5. Register review protocols externally if the team conducts a systematic review.\n\n## Top gaps\n\n""" + "\n".join([f"- {g}" for g in gaps]) + "\n"
