import json
from pathlib import Path

FORBIDDEN = [
    "subprocess", "os.system", "eval(", "exec(", "socket", "requests", "urllib", "http.client", "ftplib", "paramiko",
    "pickle.loads", "shutil.rmtree", "chmod", "chown", "browser", "selenium"
]

def run_static_audit(src_dir: str):
    findings=[]
    root=Path(src_dir)
    for p in root.rglob("*.py"):
        if p.name == "static_audit.py":
            continue
        text=p.read_text(encoding="utf-8", errors="ignore")
        for term in FORBIDDEN:
            if term in text:
                findings.append({"file":str(p),"term":term})
    return {
        "pass": len(findings)==0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, hidden telemetry, destructive host mutation, or clinical decision automation in the offline core."
    }

def write_audit(src_dir: str, out_file: str):
    result=run_static_audit(src_dir)
    Path(out_file).parent.mkdir(parents=True, exist_ok=True)
    Path(out_file).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    return result
