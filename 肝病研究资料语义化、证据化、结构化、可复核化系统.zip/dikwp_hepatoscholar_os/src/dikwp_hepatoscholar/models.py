from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

@dataclass
class LiteratureRecord:
    record_id: str
    title: str
    abstract: str = ""
    year: Optional[int] = None
    journal: str = ""
    doi: str = ""
    pmid: str = ""
    source_type: str = "article"
    study_design: str = "unknown"
    sample_size: Optional[int] = None
    disease_area: List[str] = field(default_factory=list)
    population: str = ""
    intervention_or_exposure: str = ""
    comparator: str = ""
    outcome: str = ""
    conclusion: str = ""
    keywords: List[str] = field(default_factory=list)
    synthetic: bool = False

@dataclass
class DIKWPLedgerEntry:
    record_id: str
    D: Dict[str, Any]
    I: Dict[str, Any]
    K: Dict[str, Any]
    W: Dict[str, Any]
    P: Dict[str, Any]
    R: Dict[str, Any]

@dataclass
class ClaimCard:
    claim_id: str
    record_id: str
    claim_text: str
    disease_area: str
    evidence_type: str
    evidence_score: float
    decision: str
    support_scope: str
    residual: str
    kill_condition: str

@dataclass
class ClosureResult:
    record_id: str
    primary_anchors: List[str]
    local_noise: List[str]
    residuals: List[str]
    stability_level: str
    stability_score: float
    rationale: str

@dataclass
class AnalysisReport:
    system: str
    version: str
    record_count: int
    decision_summary: Dict[str, int]
    topic_counts: Dict[str, int]
    mean_evidence_score: float
    top_research_gaps: List[str]
    medical_boundary: str


def to_dict(obj):
    return asdict(obj)
