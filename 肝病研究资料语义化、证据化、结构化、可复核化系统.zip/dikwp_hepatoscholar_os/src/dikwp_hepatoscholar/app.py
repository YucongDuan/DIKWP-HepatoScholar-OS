def main():
    try:
        import streamlit as st
    except Exception:
        print("Install with: pip install -e .[app]")
        return
    st.title("DIKWP HepatoScholar OS")
    st.write("Offline-first liver disease literature semantic ledger and research mining system.")
    st.warning("Research organization only; not for clinical diagnosis or treatment decisions.")

if __name__ == "__main__":
    main()
