import re
from typing import List

_SENT_RE = re.compile(r"(?<=[.!?。！？])\s+")

def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()

def split_sentences(text: str) -> List[str]:
    text = normalize_text(text)
    if not text:
        return []
    parts = _SENT_RE.split(text)
    return [p.strip() for p in parts if p.strip()]

def contains_any(text: str, terms) -> bool:
    t = (text or "").lower()
    return any(term.lower() in t for term in terms)

def safe_slug(text: str) -> str:
    text = re.sub(r"[^A-Za-z0-9_-]+", "-", text.strip())
    return text.strip("-").lower() or "item"
