import argparse
import json
from pathlib import Path
from .analyzer import analyze
from .static_audit import write_audit

def main():
    parser = argparse.ArgumentParser(prog="hepatoscholar")
    sub = parser.add_subparsers(dest="cmd", required=True)
    p1 = sub.add_parser("analyze")
    p1.add_argument("input")
    p1.add_argument("--out", default="outputs/demo")
    p2 = sub.add_parser("static-audit")
    p2.add_argument("src")
    p2.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args = parser.parse_args()
    if args.cmd == "analyze":
        result = analyze(args.input, args.out)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.cmd == "static-audit":
        result = write_audit(args.src, args.out)
        print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
