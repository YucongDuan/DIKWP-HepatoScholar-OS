# Architecture

DIKWP HepatoScholar OS has seven layers:

1. **Corpus Intake**: imports JSON/CSV-style literature metadata.
2. **Term Router**: detects liver disease domains and MeSH/free-text concepts.
3. **DIKWP Ledger**: registers records as D/I/K/W/P/R.
4. **Evidence Matrix**: scores evidence design, completeness, bias signals, and source identifiers.
5. **3NO SemanticClosure**: handles incomplete, imprecise and inconsistent records by separating primary anchors, local noise and residuals.
6. **Research Gap Miner**: identifies under-studied topics, populations, endpoints and translation gaps.
7. **Report Generator**: exports JSON, CSV and Markdown outputs for human review.

The offline core intentionally avoids network calls. Teams may import PubMed, Europe PMC or ClinicalTrials.gov exports manually, or develop optional connectors outside the core.
