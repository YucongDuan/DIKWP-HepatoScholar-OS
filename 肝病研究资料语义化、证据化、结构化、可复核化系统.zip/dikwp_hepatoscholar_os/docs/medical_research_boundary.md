# Medical Research Boundary

DIKWP HepatoScholar OS is a research organization and evidence mapping tool. It does not provide medical advice.

## Allowed

- Literature organization
- Evidence mapping
- Research-gap discovery
- Review preparation
- PICO/PECO structuring
- Hypothesis generation
- Full-text review prioritization

## Not allowed

- Diagnosis
- Treatment recommendation
- Prescription
- Patient triage
- Clinical risk scoring for individual patients
- Replacing expert hepatologists or ethics review
- Claiming guideline-level evidence without human formal review

## Kill conditions

Downgrade or block any output if:

- It makes patient-specific recommendations.
- It lacks a source identifier and still makes strong claims.
- It treats synthetic demo records as real evidence.
- It collapses guideline, trial, mechanistic and case-report evidence into one level.
- It omits population, endpoint or denominator.
