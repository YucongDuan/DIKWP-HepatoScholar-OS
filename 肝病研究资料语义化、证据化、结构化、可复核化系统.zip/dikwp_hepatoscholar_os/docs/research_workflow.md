# Research Workflow

## 1. Define P-layer research purpose

Examples:

- Map fibrosis biomarkers in MASLD.
- Identify evidence gaps in HBV-related HCC risk.
- Prepare a systematic review protocol for MASH therapies.

## 2. Build search strategy

Use both controlled vocabulary and free text. For biomedical literature, MeSH should be considered when using PubMed/MEDLINE. Add older and newer liver disease terms, such as NAFLD/NASH and MASLD/MASH, to avoid terminology drift.

## 3. Export metadata

Export metadata from literature databases into a structured file. Include title, abstract, year, journal, DOI, PMID, study design, population, intervention/exposure, comparator and endpoint where possible.

## 4. Run HepatoScholar

```bash
hepatoscholar analyze corpus.json --out outputs/project_x
```

## 5. Human review

Use `evidence_anchor` records for full-text extraction. Use `hypothesis_only` records for mechanism mapping or future-search design.

## 6. Protocol discipline

If the output will become a systematic review, do not treat this tool as a replacement for PRISMA, PROSPERO registration, risk-of-bias assessment or statistical methods.
