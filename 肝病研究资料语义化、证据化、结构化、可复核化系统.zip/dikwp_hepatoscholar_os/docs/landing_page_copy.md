# Landing Page Copy

## DIKWP HepatoScholar OS

Turn liver disease literature overload into a DIKWP evidence ledger.

Organize hepatology papers, trial records and review materials into disease topics, PICO/PECO anchors, claim cards, evidence matrices and research-gap maps.

Built for researchers. Not for clinical decisions.
