# Integration Guide

## With ProofLedger
Export `claim_cards.csv` to ProofLedger for claim-to-source review.

## With SemanticClosure OS
Use `semantic_closure_report.json` as an input for broader 3NO closure tasks.

## With TrustPassport
Register official HepatoScholar modules and curated query templates.

## With RAG systems
Use only `evidence_anchor` records after full-text verification as high-quality RAG seed documents.
