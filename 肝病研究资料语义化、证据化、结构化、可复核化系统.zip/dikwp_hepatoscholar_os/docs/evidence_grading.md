# Evidence Grading Model

The current scoring is a lightweight prototype. It uses study design, sample size, source identifiers, recency and overclaim penalties.

## Example hierarchy

- Meta-analysis / systematic review: strong evidence anchor only after methods review.
- Randomized trial: strong evidence for its population and endpoint.
- Cohort study: useful association evidence, not automatic causality.
- Mechanistic study: hypothesis and mechanism support.
- Case report / case series: signal generation only.
- Guideline: practice-context anchor, but must be separated from primary evidence.

## DIKWP reliability labels

- Supported
- Provisional-Supported
- Provisional
- Weak

No score alone should be used as a clinical decision.
