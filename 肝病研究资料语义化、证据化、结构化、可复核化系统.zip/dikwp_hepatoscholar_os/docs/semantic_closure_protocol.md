# 3NO SemanticClosure Protocol for Hepatology

Liver disease literature often contains three-no conditions:

1. **Incomplete**: missing denominator, population, endpoint, dose, follow-up or full text.
2. **Imprecise**: vague association language, exploratory endpoints, mixed nomenclature.
3. **Inconsistent**: different disease definitions, old/new terminology, conflicting outcomes, heterogeneous trials.

The system separates:

- Primary anchors: disease, study design, population, intervention/exposure, endpoint, sample size.
- Local noise: imprecise language, preliminary claims, scale shifts, terminology drift.
- Residuals: missing full text, missing denominator, hidden comparator, unverified source.

SemanticClosure levels:

- S4 Stable Closure
- S3 Supported Closure
- S2 Provisional Closure
- S1 Fragile Closure
- S0 Blocked Closure
