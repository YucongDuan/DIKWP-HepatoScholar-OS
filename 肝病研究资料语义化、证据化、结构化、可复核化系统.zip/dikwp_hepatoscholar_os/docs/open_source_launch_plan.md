# Open Source Launch Plan

## Recommended GitHub repository

`YucongDuan/DIKWP-HepatoScholar-OS`

## Launch sequence

1. Publish README, sample corpus, CLI and demo outputs.
2. Add GitHub Actions for tests.
3. Invite hepatology researchers to test metadata ingestion.
4. Publish a short article: "DIKWP for Hepatology Literature SemanticClosure".
5. Create issue templates for disease modules: MASLD/MASH, HBV, HCC, cirrhosis, DILI, transplant.

## Value layer

Keep official DIKWP HepatoScholar Review, registry, expert-curated templates, and institutional pilots as value-added services.
