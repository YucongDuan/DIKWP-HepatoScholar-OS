# GitHub Release Draft

## DIKWP HepatoScholar OS v0.1.0

This first release provides an offline-first DIKWP semantic ledger for liver disease literature. It includes a sample hepatology corpus, evidence matrix, claim cards, semantic closure report, gap mining and safety boundaries.

### Highlights

- DIKWP D/I/K/W/P/R literature ledger
- Liver disease topic routing
- Evidence score prototype
- 3NO SemanticClosure for incomplete/imprecise/inconsistent records
- Research-gap report
- Static boundary audit

### Boundary

Research organization only. Not for diagnosis or treatment.
