# Source Synthesis

The system design aligns with:

- PubMed / Entrez as a major biomedical literature access route.
- MeSH as a controlled vocabulary for PubMed indexing.
- Europe PMC as a large literature and open full-text access point.
- ClinicalTrials.gov API as a structured source for clinical study records.
- PRISMA 2020 and protocol registration practices as formal systematic-review boundaries.
- MASLD/MASH terminology transition, which requires synonym handling and nomenclature drift awareness in liver disease searches.
- DIKWP 4.0 SemanticClosure: incomplete, imprecise and inconsistent academic materials must be handled by anchor-ledger, unit/scope closure, residual and reliability labels.
