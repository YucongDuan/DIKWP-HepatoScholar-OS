# Roadmap

## v0.2
- CSV and BibTeX ingestion
- PubMed XML import
- PRISMA flow diagram helper
- Risk-of-bias checklist templates

## v0.3
- Full-text section extraction
- MeSH expansion helper
- Disease-specific modules

## v0.4
- Optional online connectors outside offline core
- Europe PMC annotations adapter
- ClinicalTrials.gov status tracker

## v1.0
- Official DIKWP HepatoScholar Review Pack
- Research group pilot workflow
- TrustPassport integration
