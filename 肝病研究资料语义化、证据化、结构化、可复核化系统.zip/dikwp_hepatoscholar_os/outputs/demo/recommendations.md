# DIKWP HepatoScholar Recommendations

## Current decision summary

{
  "reviewable_support": 1,
  "evidence_anchor": 4,
  "weak_or_context_only": 1,
  "hypothesis_only": 2
}

## Immediate actions

1. Replace all synthetic records with exported PubMed/PMC/ClinicalTrials metadata before formal use.
2. Route `evidence_anchor` records to full-text extraction.
3. Route `hypothesis_only` records to mechanism-map or gap-mining use only.
4. Add missing pediatric, cost-effectiveness, quality-of-life, and implementation endpoints if relevant.
5. Register review protocols externally if the team conducts a systematic review.

## Top gaps

- Topic gap: Autoimmune records absent in current corpus; add targeted searches.
- Population gap: pediatric or adolescent liver disease evidence not represented.
- Endpoint gap: patient-reported quality-of-life endpoints not represented.
- Translation gap: cost-effectiveness / implementation endpoints are missing.
