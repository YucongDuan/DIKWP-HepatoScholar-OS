# Liver Disease Query Strategy Pack

## Core search blocks

### MASLD / MASH
`(MASLD OR MASH OR NAFLD OR NASH OR steatotic liver disease OR steatohepatitis) AND (fibrosis OR biomarker OR therapy OR outcome)`

### Viral hepatitis
`(hepatitis B OR HBV OR hepatitis C OR HCV) AND (antiviral OR cure OR fibrosis OR cirrhosis OR hepatocellular carcinoma)`

### HCC
`(hepatocellular carcinoma OR HCC OR liver cancer) AND (immunotherapy OR surveillance OR biomarker OR survival)`

### Cirrhosis / portal hypertension
`(cirrhosis OR portal hypertension OR varices OR ascites) AND (noninvasive OR beta blocker OR TIPS OR outcome)`

## Recommended sources

- PubMed / MEDLINE for biomedical citations.
- Europe PMC for publications, preprints and open full-text links.
- ClinicalTrials.gov for trial status and study records.
- Guideline sources such as AASLD/EASL for practice guidance, with clear separation from research hypotheses.

## Workflow

1. Draft PICO/PECO question.
2. Build search terms with MeSH plus free-text synonyms.
3. Export metadata to JSON/CSV/BibTeX.
4. Ingest into HepatoScholar.
5. Review DIKWP evidence ledger and semantic closure report.
6. Route evidence anchors to full-text extraction and expert review.
