# DIKWP HepatoScholar Research Gap Report

## Topic distribution

- MASLD/MASH: 2
- Fibrosis: 3
- HBV: 1
- HCC: 2
- Cirrhosis: 2
- DILI: 1
- Transplantation: 1
- Cholestatic: 1

## Top gaps

- Topic gap: Autoimmune records absent in current corpus; add targeted searches.
- Population gap: pediatric or adolescent liver disease evidence not represented.
- Endpoint gap: patient-reported quality-of-life endpoints not represented.
- Translation gap: cost-effectiveness / implementation endpoints are missing.

## DIKWP 4.0 interpretation

Research gaps are not only missing data. They may be missing denominators, endpoints, populations, mechanisms, full-text links, or P-layer research purpose. Use this report to plan targeted searches, full-text extraction, and expert review.