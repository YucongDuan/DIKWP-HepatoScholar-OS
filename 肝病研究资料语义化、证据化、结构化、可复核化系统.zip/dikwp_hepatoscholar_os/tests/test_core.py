from pathlib import Path
import json
from dikwp_hepatoscholar.analyzer import analyze
from dikwp_hepatoscholar.static_audit import run_static_audit

ROOT = Path(__file__).resolve().parents[1]

def test_analyze_demo(tmp_path):
    result = analyze(str(ROOT/"examples/sample_liver_research_corpus.json"), str(tmp_path))
    assert result["record_count"] == 8
    assert (tmp_path/"hepatoscholar_report.json").exists()
    assert (tmp_path/"claim_cards.csv").exists()


def test_static_audit_passes():
    result = run_static_audit(str(ROOT/"src"))
    assert result["pass"] is True


def test_semantic_closure_output(tmp_path):
    analyze(str(ROOT/"examples/sample_liver_research_corpus.json"), str(tmp_path))
    data = json.loads((tmp_path/"semantic_closure_report.json").read_text(encoding="utf-8"))
    assert len(data) == 8
    assert any(item["stability_level"].startswith("S") for item in data)
